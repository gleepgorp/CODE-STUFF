package javaIO;

/*Write an application that takes customer orders. Allow a user to enter a customer
number and item ordered. Display an error message if the customer number does
not exist in the customer file or the item does not exist in the item file; otherwise,
display all the customer information and item information. Save the program as CustomerItemOrder.java
*/
import java.io.*;
import java.util.*;

public class CustomerItemOrder 
{
	public static void main(String[] args) throws FileNotFoundException
	{
		Scanner s = new Scanner(System.in);
		int custnum = 0,choice;
		String itemOrdered;
		boolean quit = false;
		
		Set<Integer> usedIDs = new HashSet<>();
		Set<String> usedItem = new HashSet<>();
		FileWriter writer = null;
		
		try
		{
			File file = new File("customerOrder.txt");
			writer = new FileWriter(file);
			
			do
			{
				System.out.println("________________________");
				System.out.println();
				System.out.println("[1] Add Order"
								+"\n[2] Check Order number"
								+"\n[3] Check Item ordered"
								+"\n[4] View items ordered"
								+"\n[0] Exit");
				System.out.println("________________________");
				choice = s.nextInt();
				switch(choice)
				{
					case 0:
						System.out.println("Order anytime!");
						quit = true;
						break;
						
					case 1:
						s.nextLine();
						System.out.print("Enter order #: ");
						custnum = s.nextInt();
						s.nextLine();
						
						System.out.print("Enter order: ");
						itemOrdered = s.nextLine();
						
						System.out.println("\nOrder added to file!");
						
						String record = String.format("Item #: %03d \nItem Ordered: %s\n\n", custnum, itemOrdered);
						writer.write(record);
						break;
						
					case 2:
						s.nextLine();
						System.out.print("Enter order #: ");
						custnum = s.nextInt();
						s.nextLine();
						if(usedIDs.contains(custnum))
						{
							System.out.println("Order number in the system.");
							continue;
						}
						else
						{
							System.out.println("Order number does not exist in the system.");
						}
						break;
						
					case 3:
						s.nextLine();
						System.out.print("Enter item name: ");
						itemOrdered = s.nextLine();
						if(usedItem.contains(custnum))
						{
							System.out.println("Item is in the system.");
							continue;
						}
						else
						{
							System.out.println("Item does not exist in the system.");
						}
						break;
					
					case 4:
						File file2 = new File("customerOrder.txt");
						Scanner scan = new Scanner(file);
						
						while(scan.hasNextLine())
						{
							System.out.println(scan.nextLine());
						}
						break;
				}
				
			}
			while(!quit);
		}
		
		catch(Exception e)
		{
			System.out.println("Error: "+e.getMessage());
		}
		finally
	    {
	       if(writer != null)
	       {
	          try
	          {
	             writer.close();
	          }
	          catch(IOException e)
	          {
	             System.out.println("Error closing file: "+e.getMessage());
	          }
	       }
	    }
	}
}
