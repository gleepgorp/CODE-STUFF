package javaIO;

// 2.	Write a program that creates a file of items carried by the company.
// Include a three-digit item number and up to a 20-character description
// for each item. Issue an error message if the user tries to store an item
// number that has already been used. Save the program as CreateItemFile.java

import java.io.*;
import java.util.*;

public class CreateItemFile
{
   public static void main(String []args)
   {
      Scanner s = new Scanner(System.in);
      int itemnum;
      String desc; 
      
      Set<Integer> usedIDs = new HashSet<>();
      FileWriter writer = null;
      
      try
      {
         File file = new File("products.txt");
         writer = new FileWriter(file);
         
         while(true)
         {
            System.out.print("Enter #: ");
            itemnum = s.nextInt();
            if(usedIDs.contains(itemnum))
            {
               System.out.print("Error: Item # already used\n");
               continue;
            }
            usedIDs.add(itemnum);
            s.nextLine();

            System.out.println("Enter description: ");
            desc = s.nextLine();

            if(desc.length() > 20)
            {
               System.out.println("Invalid description, 20 character limit only\n");
               itemnum = 0;
               continue;
            }

            String record = String.format("Item #: %03d \nDescription: %s\n", itemnum, desc);
            writer.write(record);

            System.out.println("\nRecord added to file");
            System.out.println("Add another record? (Y/N)");
            String choice = s.next();

            if(choice.equalsIgnoreCase("N"))
            {
               break;
            }
         }
         System.out.println("Done");
      }
      catch(Exception e)
      {
         System.out.println("Error: "+e.getMessage());
      }
      finally
      {
         if(writer != null)
         {
            try
            {
               writer.close();
            }
            catch(IOException e)
            {
               System.out.println("Error closing file: "+e.getMessage());
            }
         }
      }
   }
}