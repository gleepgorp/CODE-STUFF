import java.util.*;
public class UseOrder
{
   public static void main(String [] args)
   {
      String customerName;
      int quantity, customerNumber;
      double unitPrice;
      
      Order o = new ShippedOrder();
      Scanner s = new Scanner(System.in);
      
      System.out.print("Enter name: ");
      customerName = s.nextLine();
      o.setcustomerName(customerName);
      
      System.out.print("Enter customer #: ");
      customerNumber = s.nextInt();
      o.setcustomerNumber(customerNumber);
      
      System.out.print("Enter quantity: ");
      quantity = s.nextInt();
      o.setquantity(quantity);
      
      System.out.printf("Enter Price: ");
      unitPrice = s.nextDouble();
      o.setunitPrice(unitPrice);
      
      System.out.println(" ");
      o.compute();
      o.display();
   }
}
