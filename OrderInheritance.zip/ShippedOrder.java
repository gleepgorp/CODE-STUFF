public class ShippedOrder extends Order
{
   private double shippingFee;
   private double handlingCharge;
   
   public ShippedOrder()
   {
      this.shippingFee = 100.00;
      this.handlingCharge = 4.00;
   }
   
   @Override
   public double compute()
   {
      return totalPrice = (getquantity() * getunitPrice()) + shippingFee + handlingCharge;
   }
  
}