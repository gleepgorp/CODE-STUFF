public class Order
{
   private String customerName;
   private int quantity, customerNumber;
   double totalPrice, unitPrice;
   
   //GETTERS
   public String getcustomerName()
   {
      return customerName;
   }
   public int getquantity()
   {
      return quantity;
   }
   public int getcustomerNumber()
   {
      return customerNumber;
   }
   public double gettotalPrice()
   {
      return totalPrice;
   }
   public double getunitPrice()
   {
      return unitPrice;
   }
   
   //SETTERS
   public void setcustomerName(String customerName)
   {
      this.customerName = customerName;
   }
   public void setquantity(int quantity)
   {
      this.quantity = quantity;
   }
   public void setcustomerNumber(int customerNumber)
   {
      this.customerNumber = customerNumber;
   }
   public void settotalPrice(double totalPrice)
   {
      this.totalPrice = totalPrice;
   }
   public void setunitPrice(double unitPrice)
   {
      this.unitPrice = unitPrice;
   }
   
   public double compute()
   {
      return totalPrice = unitPrice * quantity;
   }
   
   public void display()
   {
      System.out.println("Name: "+this.customerName);
      System.out.println("Customer Number: "+this.customerNumber);
      System.out.println("Quantity: "+this.quantity);
      System.out.printf("Unit Price: %.2f \n",this.unitPrice);
      System.out.printf("Total Price: %.2f",this.totalPrice);
   }
}