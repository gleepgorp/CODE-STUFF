// 2.	Write a program that creates a file of items carried by the company.
// Include a three-digit item number and up to a 20-character description
// for each item. Issue an error message if the user tries to store an item
// number that has already been used. Save the program as CreateItemFile.java

import java.io.*;
import java.util.*;

public class CreateItemFile
{
   public static void main(String []args)
   {
      Scanner s = new Scanner(System.in);
      int itemnum;
      String desc; 
      
      Set<Integer> usedIDs = new HashSet<>
      FileWriter writer = null;
      
      try
      {
         File file = new File("Items.txt");
         writer = new FileWriter(file);
         
         while(true)
         {
            System.out.print();
            itemnum = s.nextInt();
            if(usedIDs.contains(idnumber))
            {
               System.out.print("Error: Item # already used\n");
               continue;
            }
            usedIDs.add(itemnum);
            
            System.out.print("Enter");
         }
      }
      catch()
      {
      
      }
   }
}