// The first part of the program should create an empty file 
// suitable for writing a three-digit ID number, six-character last name, and five-digit zip 
// code for each customer. should create an empty file suitable for writing a three-digit ID 
// number, six-character last name, and five-digit zip code for each customer. 

// The second half of the program accepts user input to populate the file. 
// For this exercise, assume that the user will correctly enter ID numbers and
// zip codes, but force the customer name to seven characters if it is too
// long or too short. Issue an error message, and do not save the records if
// the user tries to save a record with an ID number that has already been used

import java.io.*;
import java.util.*;

public class CreateCustomerFile 
{
    public static void main(String[] args) 
    {
        Scanner s = new Scanner(System.in);
        int idnumber, zipcode;
        String lastname;

        Set<Integer> usedIds = new HashSet<>();
        FileWriter writer = null;

        try 
        {
            File file = new File("customer.txt");
            writer = new FileWriter(file);

            while(true) 
            {
                System.out.print("Enter ID #: ");
                idnumber = s.nextInt();
                if (usedIds.contains(idnumber)) 
                {
                    System.out.println("Error: ID number already used\n");
                    continue; 
                }
                usedIds.add(idnumber);

                System.out.print("Enter Zipcode #: ");
                zipcode = s.nextInt();
                s.nextLine();
                
                System.out.print("Enter last name: ");
                lastname = s.nextLine();
                

                if (lastname.length() > 7 || lastname.length() < 7) 
                {
                    System.out.println("Invalid number of characters, Enter 7 characters\n");
                    continue;
                }

                String record = String.format("ID #: %03d \nZipcode #: %05d \nLast name: %s\n", idnumber, zipcode, lastname);
                writer.write(record);

                System.out.println("\nRecord added to file");
                System.out.print("Add another record? (Y/N) ");
                String choice = s.next();
                
                if (choice.equalsIgnoreCase("N")) 
                {
                    break;
                }
            }

            System.out.println("Done");
        } 
        catch (Exception e) 
        {
            System.out.println("Error: " + e.getMessage());
        } 
        finally 
        {
            if (writer != null) 
            {
                try 
                {
                    writer.close();
                } 
                catch (IOException e) 
                {
                    System.out.println("Error closing file: " + e.getMessage());
                }
            }
        }
    }
}
