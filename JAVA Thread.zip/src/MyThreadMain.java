
public class MyThreadMain {

	public static void main(String[] args) {
		
		for(int i = 1; i <= 5; i++) {
			MyThread mythread = new MyThread(i);
			mythread.start();
		}
	}

}
