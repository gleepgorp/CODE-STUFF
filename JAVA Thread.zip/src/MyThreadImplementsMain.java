
public class MyThreadImplementsMain {

	public static void main(String[] args) {
		
		for(int i = 1; i <= 5; i++) {
			MyThreadImplements mythreadimp = new MyThreadImplements(i); 
			Thread thread = new Thread(mythreadimp);
			thread.start();
		}
	}

}

