
public class MyThreadImplements implements Runnable{
	
	private int threadNumber;
	public MyThreadImplements(int threadNumber) {
		this.threadNumber = threadNumber;
	}
	@Override
	public void run() {
		for(int i = 1; i <= 5; i++) {
			System.out.println("World "+threadNumber);
			
			try {
				Thread.sleep(800);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
