import java.util.*;
public class MyThreadExceptionMain {

	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		int threadNum;
      System.out.print("Enter number of thread: ");
      threadNum = s.nextInt();
		for(int i = 1; i <= threadNum; i++) {
			MyThread mythread = new MyThread(i);
			mythread.start();
		}
	}

}

